# cs162_groupProject
Group project for CS162

## Group Members

* Charles Chen
* Zach Morrissey
* Eve Robitaille
* Cody Schmidlin
* Beau Shirdavani
* Brian Trang
* Mark Walker

## Description
Basic Rock/Paper/Scissors game. Allows the user to select their choice and battle the computer.


### Notes from Development:

- Need to include `std::srand(std::time(NULL));` in main() to avoid issues with random numbers
- Required to merge all header files into one. Project requirement.